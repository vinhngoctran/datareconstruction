clear all; close all; clc
load('FinalResults2/Validation.mat',"Metrics_GT");
load('Map/Col.mat');
load('FinalResults2/Validation2.mat',"EvalV1","EvalV2","MaxV","MinV");
load('FinalResults2\3_GT_Rec.mat', 'Infor','Depth')

load('FinalResults2/Regional.mat',"REGST");

AreaName = ["Greenland","North America","Europe","Asia","Africa"];
ModedC = ["#0072BD","#7E2F8E","#77AC30","#D95319"];
ModelName = ["ANN","SVM","RF","LSTM"];
MetricsName = ["R^2 [-]","KGE [-]"];
MetricsName2 = ["R^2","KGE"];
load('FinalResults2/Profile.mat',"Nearest","LatV","LonV")
for i=1:3
    OBS{1,i} = MaxV{1}(Nearest{1,i},1);
    SIM{1,i} = MaxV{1}(Nearest{1,i},2);
    R2{1,i} = EvalV1{1}(Nearest{1,i},3);

    OBS{2,i} = MinV{1}(Nearest{1,i},1);
    SIM{2,i} = MinV{1}(Nearest{1,i},2);
    R2{2,i} = EvalV1{1}(Nearest{1,i},1);

    OBS{3,i} = MaxV{2}(Nearest{2,i},1);
    SIM{3,i} = MaxV{2}(Nearest{2,i},2);
    R2{3,i} = EvalV1{2}(Nearest{1,i},3);
    
    OBS{4,i} = [];
    SIM{4,i} = [];
    R2{4,i} = [];

    OBS{5,i} = [];
    SIM{5,i} = [];
    R2{5,i} = [];
    for j=1:numel(Nearest{3,i})
        OBS{4,i} = [OBS{4,i};MaxV{3}{Nearest{3,i}(j)}(:,1)];
        SIM{4,i} = [SIM{4,i};MaxV{3}{Nearest{3,i}(j)}(:,2)];
        R2{4,i} = [R2{4,i};EvalV1{3}{Nearest{3,i}(j)}(:,3)];

        OBS{5,i} = [OBS{5,i};MinV{3}{Nearest{3,i}(j)}(:,1)];
        SIM{5,i} = [SIM{5,i};MinV{3}{Nearest{3,i}(j)}(:,2)];
        R2{4,i} = [R2{4,i};EvalV1{3}{Nearest{3,i}(j)}(:,1)];
        
    end
end
%%
LLC = ["#0072BD","#D95319","#77AC30"];
fig = figure(1);set(gcf,'Position', [200 0 1300 1000]);
Dataname = ["Air temperature","Snow depth","Ground temperature"];
tt = ["(a) Ta_{max}","(b) Ta_{min}","(c) Sd_{max}","(d) Tg_{max}","(e) Tg_{min}","(f) Ta_{max}","(g) Ta_{min}","(h) Sd_{max}","(i) Tg_{max}","(j) Tg_{min}",...
    "(k) Ta_{max}","(l) Ta_{min}","(m) Sd_{max}","(n) Tg_{max}","(o) Tg_{min}"];
axes1 = axes('Parent',fig,'Position',[0.02 0.6 0.3 0.3]);hold on;
ncpolarm('lat',30,'grid','label');hold on
for kk=1:3
    try;geoshow(LatV{kk},LonV{kk},"Color",LLC{kk},"LineWidth",2);catch;end
end
set(axes1,'Color','none','Linewidth',2,'FontSize',13,'layer','top');
k=0;
for jj=1:3
    for i=1:5
        k=k+1;
        axes1 = axes('Parent',fig,'Position',[0.32+(i-1)*0.12 0.77-(jj-1)*0.17 0.11 0.13]);hold on;title(tt{k},'Color',LLC{jj});axes1.TitleHorizontalAlignment = 'left';
        box on;
        set(axes1,'Color','none','Linewidth',1,'FontSize',12,'layer','top','XTickLabel',[],'Yticklabel',[]);
        scatter(OBS{i,jj},SIM{i,jj},'MarkerEdgeColor',LLC{jj});
        xlim([min(OBS{i,jj}) max(OBS{i,jj})]);ylim([min(OBS{i,jj}) max(OBS{i,jj})]);
        plot([min(OBS{i,jj}) max(OBS{i,jj})],[min(OBS{i,jj}) max(OBS{i,jj})],LineWidth=1,Color='k')
        if jj==3
            xlabel('Observation')
        end
        if i==1
            ylabel('Derivation')
        end
        mdl = fitlm(OBS{i,jj},SIM{i,jj});
%         R2v = mean(R2{i,jj},'omitnan');
%         R2v = ComputeR2(OBS{i,jj},SIM{i,jj});
        R2v = mdl.Rsquared.Ordinary;
        
        annotation(fig,'textbox',...
    [0.32+(i-1)*0.12 0.87-(jj-1)*0.17 0.1 0.03],...
    'String',{['R^2 = ',num2str(round(R2v,3))]},...
    'LineStyle','none','FontSize',12);
    end
end
exportgraphics(fig,"Figures2/F4_Evaluation_31.png",'Resolution',600)