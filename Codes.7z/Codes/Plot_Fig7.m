clear all; close all; clc
load('FinalResults2/Validation.mat',"Metrics_GT");
load('Map/Col.mat');
load('FinalResults2/Validation2.mat',"EvalV1","EvalV2","MaxV","MinV");
load('FinalResults2\3_GT_Rec.mat', 'Infor','Depth')
load('FinalResults2/Regional.mat',"REGST");

AreaName = ["Greenland","North America","Europe","Asia","Africa"];
ModedC = ["#0072BD","#7E2F8E","#77AC30","#D95319"];
ModelName = ["ANN","SVM","RF","LSTM"];
MetricsName = ["R^2 [-]","KGE [-]"];
MetricsName2 = ["R^2","KGE"];
load('FinalResults2/Profile.mat',"Nearest","LatV","LonV")
for i=1:3
    DATA{i,1} = [];
    DATA{i,2} = [];
    for j=1:numel(Nearest{3,i})
        for k=1:size(MaxV{3}{Nearest{3,i}(j)},1)
            Datatemp = [Infor(Nearest{3,i}(j),:), Depth{Nearest{3,i}(j),1}(k),Infor(Nearest{3,i}(j),3)-Depth{Nearest{3,i}(j),1}(k)];
            DATA{i,1} = [DATA{i,1};[Datatemp MaxV{3}{Nearest{3,i}(j)}(k,1)]];
            DATA{i,2} = [DATA{i,2};[Datatemp MaxV{3}{Nearest{3,i}(j)}(k,2)]];  
        end
    end
    DATA{i,3} = [DATA{i,1}(:,1:end-1),DATA{i,1}(:,end)-DATA{i,2}(:,end)];
end
%%
close all
LLC = ["#0072BD","#D95319","#77AC30"];
fig = figure(1);set(gcf,'Position', [200 0 1300 900]);
Dataname = ["Air temperature","Snow depth","Ground temperature"];
tt = ["Observation","Derivation","Difference"];
ProF = ["Profile #1","Profile #2","Profile #3"];

for jj=1:3
    for i=1:3
        axes1 = axes('Parent',fig,'Position',[0.06+(i-1)*0.295 0.72-(jj-1)*0.32 0.285 0.25]);hold on;
        if jj==1
        title(tt{i});
        end
        if jj==1
        x = double(DATA{jj, i}(:,2));
        else
            x = double(DATA{jj, i}(:,1));
        end
        y = double(DATA{jj, i}(:,4));
        z = double(DATA{jj, i}(:,6));
        N = 1000;
        [X, Y] = meshgrid(linspace(min(x)-0.1, max(x)+0.1, N), linspace(0, max(y), N));
        F = scatteredInterpolant(x, y, z);
        Z = F(X, Y);
        Z(Z>max(z)) = max(z);
        Z(Z<min(z)) = min(z);
        [C,h] = contourf(X, Y, Z,'LineStyle','--','LineWidth',0.5,'LineColor',[0.5 0.5 0.5]);
%         x = double(DATA{1, 1}(:,2));
%         y = double(DATA{1, 1}(:,5));
%         z = double(DATA{1, 1}(:,6));
        scatter(x,y,'Marker','+','MarkerEdgeColor','k','SizeData',5);
        % clabel(C)
        % text(x, y, dt);
        colormap(jet)
        if jj==1 && i==1
        hcb = colorbar(axes1,'Position',...
    [0.96 0.72 0.0164102564102567 0.25]);
        hcb.Title.String = 'Tg [^oC]';
        end
        clim([-15 35]);
%         contourf(DATA{1, 1}(:,2),DATA{1, 1}(:,5),DATA{1, 1}(:,6));
        if i==3
            ylabel(ProF{jj});
            axes1.YAxisLocation = "right";
        end
        if i>1
            axes1.YTickLabel = [];
        else
            ylabel('Soil depth [m]');
        end
        if jj==1
            xlabel('Longitude');
        else
            xlabel('Latitude');
        end
        box on;ylim([0 max(y)]);xlim([min(x)-0.1 max(x)]);
        set(axes1,'Color','none','Linewidth',1,'FontSize',12,'layer','top','YDir','reverse');
  
    end
end
exportgraphics(fig,"Figures2/F5_Evaluation_31.png",'Resolution',600)