clear all; close all; clc
load('FinalResults2/Validation.mat',"Metrics_GT","Metrics");
load('Map/Col.mat');
load('FinalResults2\1_AirTem_Raw.mat', 'Infor');
Infoall{1}=Infor;
load('FinalResults2\2_SND_Raw.mat', 'Infor');
Infoall{2}=Infor;
load('FinalResults2\3_GT_Rec.mat', 'Infor')
Infoall{3}=Infor;
ModedC = ["#0072BD","#7E2F8E","#77AC30","#D95319"];
ModelName = ["ANN","SVM","RF","LSTM"];
MetricsName = ["R^2 [-]","KGE [-]"];
MetricsName2 = ["R^2","KGE"];
n = 10;
DT = 1/n;
cmap = flip(jet(n));
GAPV = [0:0.1:1];
for i=1:numel(Metrics_GT)
    Metrics{3}(i,1:2) = mean(Metrics_GT{i,1}(:,1:2),"omitnan");
    for j=1:4
        Model(j) = sum(Metrics_GT{i,1}(:,3)==j) / numel(Metrics_GT{i,1}(:,3));
    end
    idx=find(Model==max(Model));
    Metrics{3}(i,3) = idx(1);
end

Metrics2{1} = Metrics{1};Metrics2{2} = Metrics{2};
Metrics2{3} = [];
for i=1:numel(Metrics_GT)
    Metrics2{3} = [Metrics2{3};Metrics_GT{i,1}];
end
for i=1:3
    Metrics{i}(Metrics{i}<0)=0;
    Metrics2{i}(Metrics2{i}<0)=0;
end

fig = figure(1);set(gcf,'Position', [200 0 1300 1200]);
Dataname = ["Air temperature","Snow depth","Ground temperature"];
tt = ["(a)","(b)","(c)","(d)","(e)","(f)","(g)","(h)","(i)"];
for jj=1:3
    for i=1:2
        axes1 = axes('Parent',fig,'Position',[0.05+(jj-1)*0.3 0.71-(i-1)*0.34 0.28 0.26]);hold on;title(tt{(i-1)*3+jj});axes1.TitleHorizontalAlignment = 'left';
        ncpolarm('lat',30,'grid','label');hold on
        if i<3
            for k=1:10
                if k<10
                    idx = find(Metrics{jj}(:,i)>=GAPV(k)&Metrics{jj}(:,i)<GAPV(k+1));
                else
                    idx = find(Metrics{jj}(:,i)>=GAPV(k)&Metrics{jj}(:,i)<=GAPV(k+1));
                end
                if ~isempty(idx)
                    try;CC = cmap(k,:);geoshow(Infoall{jj}(idx,1),Infoall{jj}(idx,2),"Marker",".",'MarkerSize',10,"Color",CC,"LineStyle","None");catch;end
                end
            end
            if jj==3
                colormap(flip(jet));hcb = colorbar;
                hcb.Position = [0.31+(jj-1)*0.3 0.71-(i-1)*0.34 0.0164102564102564 0.26];
                hcb.FontSize = 12;
                hcb.Title.String = MetricsName{i};
            end
        end
        set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top');
        if i==3 && jj ==1
            axes1 = axes('Parent',fig,'Position',[0.05+(jj-1)*0.3 0.71-(i-1)*0.32 0.28 0.27]);hold on;
            for j=1:4
                lg{j} = area([1 2],[0 0],"FaceColor",ModedC{j},'FaceAlpha',0.8,'LineStyle','none','DisplayName',ModelName{j});
            end
            legend1 = legend([lg{1} lg{2} lg{3} lg{4}]);
            set(legend1,...
                'Position',[0.852410858339834 0.91296417647543 0.0715384605756173 0.0752640824082869],...
                'Color',[1 1 1]);
            set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top','XColor','None','YColor','None');
        end
%         if i==1
            ylabel(Dataname(jj));
%         end
        
        if i<3
            axes1 = axes('Parent',fig,'Position',[0.07+(jj-1)*0.3 0.68-(i-1)*0.34 0.09 0.07]);hold on;box on
            h1=cdfplot(Metrics2{jj}(:,i));title('');xlabel('');ylabel('');
            set( h1, 'Linewidth', 1, 'Color', 'k');
            set(axes1,'Linewidth',1,'FontSize',12,'layer','top','Ytick',[0 0.5 1],'Xtick',[0 0.5 1],'XTickLabel',["0",MetricsName(i),"1"],'YTickLabel',["0","F("+MetricsName2(i)+")","1"],'YTickLabelRotation',90,'XTickLabelRotation',0);
        end
    end
end
exportgraphics(fig,"Figures2/F3_Evaluation_1.png",'Resolution',600)