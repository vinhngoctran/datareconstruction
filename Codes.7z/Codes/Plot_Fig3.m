% datavariability plot
clear all; close all; clc
load('FinalResults2\1_AirTem_Raw.mat', 'DATE');
% idx = find(DATE==datetime(1981,1,1));
% DATE = DATE(idx:end);
load('FinalResults2/DataAvailability.mat',"LengthY","N_Dat");
load('Map/Col.mat');
AreaName = ["Greenland","North America","Europe","Asia","Africa"];
fig = figure(1);set(gcf,'Position', [200 50 1200 1000]);
Dataname = ["(a) Air temperature","(b) Snow depth","(c) Ground temperature-all depth","(d) Ground temperature-any"];
for i=1:4
axes1 = axes('Parent',fig,'Position',[0.08 0.8-(i-1)*0.24 0.5 0.16]);hold on;box on;title(Dataname{i});axes1.TitleHorizontalAlignment = 'left';
b = bar(DATE,N_Dat{i},"stacked");
for j=1:size(ColorF,1)
b(j).FaceColor = ColorF(j,:);
end
if i==4
xlabel('Time');
annotation(fig,'textbox',...
    [0.032 0.26400000050664 0.44166659638286 0.0269999994933605],...
    'String',{'Number of {\itin situ} gauges with data availability'},...
    'Rotation',90,...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',14,...
    'FitBoxToText','off');
end
set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top');

axes1 = axes('Parent',fig,'Position',[0.65 0.8-(i-1)*0.24 0.32 0.16]);hold on;box on;
b = bar(LengthY{i},"stacked");
for j=1:size(ColorF,1)
b(j).FaceColor = ColorF(j,:);
end
if i==1
    legend1 = legend(AreaName,'Position',[0.81777776509729 0.876086024485608 0.125833330849806 0.105999997019768]);
end
if i==4
xlabel('Years');
annotation(fig,'textbox',...
    [0.61 0.26400000050664 0.44166659638286 0.0269999994933605],...
    'String',{'Number of {\itin situ} gauges'},...
    'Rotation',90,...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',14,...
    'FitBoxToText','off');
end
set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top');
end
exportgraphics(fig,"Figures2/F2_dataavailability.png",'Resolution',600)
