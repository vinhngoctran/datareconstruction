clear all; close all; clc
load('FinalResults2/Validation.mat',"Metrics_GT");
load('Map/Col.mat');

load('FinalResults2\3_GT_Rec.mat', 'Infor','Depth')
Infor;

load('FinalResults2/Regional.mat',"REGST");

AreaName = ["Greenland","North America","Europe","Asia","Africa"];
ModedC = ["#0072BD","#7E2F8E","#77AC30","#D95319"];
ModelName = ["ANN","SVM","RF","LSTM"];
MetricsName = ["R^2 [-]","KGE [-]"];
MetricsName2 = ["R^2","KGE"];

n = 11;
DT = 1/n;
cmap = flip(jet(n));
GAPV = [0:0.1:1];
for i=1:numel(Metrics_GT)
    Metrics{3}(i,1:2) = mean(Metrics_GT{i,1}(:,1:2),"omitnan");
    for j=1:4
        Model(j) = sum(Metrics_GT{i,1}(:,3)==j) / numel(Metrics_GT{i,1}(:,3));
    end
    idx=find(Model==max(Model));
    Metrics{3}(i,3) = idx(1);
end

Metrics2{1} = Metrics{1};Metrics2{2} = Metrics{2};
Metrics2{3} = [];
for i=1:numel(Metrics_GT)
    Metrics2{3} = [Metrics2{3};Metrics_GT{i,1}];
end
for i=1:3
    Metrics{i}(Metrics{i}<0)=0;
    Metrics2{i}(Metrics2{i}<0)=0;
end

k=0;
for i=1:3
    k=k+1;
    POS(k,:) = [0.06 0.7-(i-1)*0.30 0.05 0.25];
    k=k+1;
    POS(k,:) = [0.12 0.7-(i-1)*0.30 0.1 0.25];
    k=k+1;
    POS(k,:) = [0.23 0.7-(i-1)*0.30 0.33 0.25];
    k=k+1;
    POS(k,:) = [0.57 0.7-(i-1)*0.30 0.38 0.25];
end
%%
fig = figure(1);set(gcf,'Position', [200 0 1300 800]);
Dataname = ["Air temperature","Snow depth","Ground temperature"];
tt = ["(a)","(b)","(c)"];
k=0;
for jj=1:2
    for i=1:4

        idx = find(REGST{1, 3}==i);
        k=k+1;
        axes1 = axes('Parent',fig,'Position',POS(k,:));hold on;box on;grid minor
        if jj<3
            for ii=1:numel(idx)
                for iii=1:numel(Depth{idx(ii),1})
                    if Metrics_GT{idx(ii),1}(iii,jj)<0 || isnan(Metrics_GT{idx(ii),1}(iii,jj))
                        Metrics_GT{idx(ii),1}(iii,jj) = 0;
                    end
                    Dista = abs(Metrics_GT{idx(ii),1}(iii,jj)-GAPV);
                    idy = find(Dista==min(Dista));
                    CC = cmap(idy(1),:);
                    scatter(ii,Depth{idx(ii),1}(iii),'MarkerFaceColor',CC,'MarkerEdgeColor',CC,'SizeData',10);
                end
            end
        else
            for ii=1:numel(idx)
                for iii=1:numel(Depth{idx(ii),1})
                    try;scatter(ii,Depth{idx(ii),1}(iii),'MarkerFaceColor',ModedC(Metrics_GT{idx(ii),1}(iii,jj)),'MarkerEdgeColor',ModedC(Metrics_GT{idx(ii),1}(iii,jj)),'SizeData',10);catch;end
                end
            end 
        end
       

        xlim([1 numel(idx)]);
        if i==1
            title(tt(jj),'VerticalAlignment','middle');axes1.TitleHorizontalAlignment = 'left';
            ylabel('Soil depth [m]')
        end
        if jj==1
            xlabel(AreaName{i});set(axes1,'xaxisLocation','top')
        end
        set(axes1,'Color','none','Linewidth',1.5,'FontSize',13,'layer','top','XColor',ColorF(i,:),'YColor',ColorF(i,:));
        ylim([-2 150]);set(axes1, 'YDir','reverse')
        if i>1
            axes1.YTickLabel = [];
        end
        if jj<2
            axes1.XTickLabel = [];
        end
         if jj<3 && i==4
            colormap(flip(jet));hcb = colorbar;
            hcb.FontSize = 12;
            hcb.Position = [0.96 0.7-(jj-1)*0.30 0.0164102564102564 0.25];
            hcb.Title.String = MetricsName{jj};
        elseif jj==3 && i==4
            axes1 = axes('Parent',fig,'Position',POS(k,:));hold on;
            for j=1:4
                lg{j} = area([1 2],[0 0],"FaceColor",ModedC{j},'FaceAlpha',0.8,'LineStyle','none','DisplayName',ModelName{j});
            end
            legend1 = legend([lg{1} lg{2} lg{3} lg{4}]);
            set(legend1,...
                'Position',[0.925487781416757 0.10715871916969 0.0715384605756173 0.106874997019767],...
                'Color',[1 1 1]);
            set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top','XColor','None','YColor','None');
        end
    end
end
annotation(fig,'textbox',[0.0584615384615385 0.3315 0.89 0.0375],...
    'String','{\itIn situ} gauge',...
    'LineStyle','none',...
    'HorizontalAlignment','center',...
    'FontSize',14,...
    'FitBoxToText','off');
exportgraphics(fig,"Figures2/F3_Evaluation_2.png",'Resolution',600)