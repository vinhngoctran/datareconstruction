clear all; close all; clc
% Read continent shapefile
SHP{1} =  readgeotable("Map/Continent/Greenland.shp");
SHP{2} =  readgeotable("Map/Continent/NorthAmerica.shp");
SHP{3} =  readgeotable("Map/Continent/Europe.shp");
SHP{4} =  readgeotable("Map/Continent/Asia.shp");
SHP{5} =  readgeotable("Map/Continent/Africa.shp");
load('Map/Col.mat');

% Read station location
load('FinalResults2\1_AirTem_Raw.mat', 'Infor');
Infoall{1}=Infor;
load('FinalResults2\2_SND_Raw.mat', 'Infor');
Infoall{2}=Infor;
load('FinalResults2\3_GT_Rec.mat', 'Infor')
Infoall{3}=Infor;

fig = figure(1);set(gcf,'Position', [200 50 1300 1000]);
Dataname = ["(a) Air temperature","(b) Snow depth","(c) Ground temperature"];
AreaName = ["Greenland","North America","Europe","Asia","Africa"];
for i=1:3
    axes1 = axes('Parent',fig,'Position',[0.05+(i-1)*0.3 0.5 0.28 0.4]);hold on;title(Dataname{i});axes1.TitleHorizontalAlignment = 'left';
    ncpolarm('lat',30,'grid','label');hold on
    for j=1:numel(SHP)
        try;geoshow(SHP{j},"FaceColor",ColorF(j,:),'FaceAlpha',0.8,'LineStyle','none','DisplayName',AreaName{j});catch;end 
    end
    try;geoshow(Infoall{i}(:,1),Infoall{i}(:,2),"Marker",".","Color","k","LineStyle","None",'MarkerSize',10);catch;end
    set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top');
    if i==3
        axes1 = axes('Parent',fig,'Position',[0.05+(i-1)*0.3 0.5 0.28 0.4]);hold on;
        for j=1:numel(SHP)
        lg{j} = area([1 2],[0 0],"FaceColor",ColorF(j,:),'FaceAlpha',0.8,'LineStyle','none','DisplayName',AreaName{j});
        end
        legend1 = legend([lg{1} lg{2} lg{3} lg{4} lg{5}]);
        set(legend1,...
    'Position',[0.821794874087358 0.343333336313565 0.11615384386136 0.105999997019768],...
    'Color',[1 1 1]);
        set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top','XColor','None','YColor','None');
    end
%     xlim([-180 180]);ylim([30 90]);
end

load('FinalResults2/Regional.mat',"REGST","Alldepth");
for i=1:3
    for j=1:numel(SHP)
        N_st(i,j) = numel(find(REGST{i}==j));
    end
end
for i=1:3
    R_st(i,:) = N_st(i,:)/sum(N_st(i,:))*100;
end
axes1 = axes('Parent',fig,'Position',[0.06 0.15 0.42 0.3]);hold on;box on;title('(d)');axes1.TitleHorizontalAlignment = 'left';
b=bar(R_st);
for i=1:numel(SHP)
    b(i).FaceColor = ColorF(i,:);
    xtips2 = b(i).XEndPoints;
    ytips2 = b(i).YEndPoints;
    labels2 = string(N_st(:,i));
    text(xtips2,ytips2,labels2,'HorizontalAlignment','center',...
        'VerticalAlignment','bottom','FontSize',13);
end
plot([2.5 2.5],[0 80],'LineStyle','--','Color','k');
plot([1.5 1.5],[0 80],'LineStyle','--','Color','k');
ylabel('Proportion of {\itin situ} gauges [%]');
set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top','XTick',[1 2 3],'XTickLabel',["Air temperature","Snow depth","Ground temperature"]);

%%
% GapData = [-2,0,0.5,1,2,3,5,7,10,20,30,50,100,150];
DEPTH = ["[−2-0]","[0-0.5]","[0.5-1]","[1-2]","[2-3]","[3-5]","[5-7]","[7-10]","[10-20]","[20-30]","[30-50]","[50-100]","[100-150]"];
axes1 = axes('Parent',fig,'Position',[0.57 0.15 0.25 0.3]);hold on;box on;title('(e)');axes1.TitleHorizontalAlignment = 'left';
b = barh(flip(Alldepth),'stacked');
for i=1:numel(SHP)
b(i).FaceColor = ColorF(i,:);
end
ylim([0.5 13.5]);
xlabel('Number of {\itin situ} gauges');ylabel('Soil depth [m]');
set(axes1,'Color','none','Linewidth',1,'FontSize',13,'layer','top','YTick',[1:1:13],'Yticklabel',flip(DEPTH));

exportgraphics(fig,"Figures2/F1_Stations.png",'Resolution',600)